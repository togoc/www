self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9a9160e923d83a2179cc9a37cf934f72",
    "url": "/indexindex.html"
  },
  {
    "revision": "cfa9e540103bf45f0f3e",
    "url": "/indexstatic/css/2.88ea2c67.chunk.css"
  },
  {
    "revision": "d6c7a9dad2e48e3959b9",
    "url": "/indexstatic/css/main.5d25192c.chunk.css"
  },
  {
    "revision": "cfa9e540103bf45f0f3e",
    "url": "/indexstatic/js/2.ef90d6ad.chunk.js"
  },
  {
    "revision": "86afaa925e0f432774bf95b19b6933fb",
    "url": "/indexstatic/js/2.ef90d6ad.chunk.js.LICENSE"
  },
  {
    "revision": "d6c7a9dad2e48e3959b9",
    "url": "/indexstatic/js/main.351827b7.chunk.js"
  },
  {
    "revision": "46c75be86e50484e0f2c",
    "url": "/indexstatic/js/runtime-main.1f3324a9.js"
  }
]);