self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f4a79f8a8dbc90ed643f939adea986f0",
    "url": "./index.html"
  },
  {
    "revision": "54494b910a2f455c8561",
    "url": "./static/css/2.88ea2c67.chunk.css"
  },
  {
    "revision": "d6c7a9dad2e48e3959b9",
    "url": "./static/css/main.5d25192c.chunk.css"
  },
  {
    "revision": "54494b910a2f455c8561",
    "url": "./static/js/2.af36de08.chunk.js"
  },
  {
    "revision": "86afaa925e0f432774bf95b19b6933fb",
    "url": "./static/js/2.af36de08.chunk.js.LICENSE"
  },
  {
    "revision": "d6c7a9dad2e48e3959b9",
    "url": "./static/js/main.351827b7.chunk.js"
  },
  {
    "revision": "75f25539e77aa1c7000e",
    "url": "./static/js/runtime-main.40bde11a.js"
  }
]);